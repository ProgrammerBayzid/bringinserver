const express = require("express");
const app = express();
const Recruiters = require("../../Model/Recruiter/recruiters");
const tokenverify = require("../../MiddleWare/tokenverify.js")
const jwt = require('jsonwebtoken');
const RecruiterFunctionarea = require("../../Model/Recruiter/Recruiter_Functionarea/recruiter_functionarea.js")
const multer = require("multer");
const JobPost = require('../../Model/Recruiter/Job_Post/job_post.js')
const {
    Profiledata,
} = require("../../Model/Seeker_profile_all_details.js");
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "uploads");
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
        cb(null, file.originalname);
    },
});
const upload = multer({ storage: storage });



app.get("/candidate_functionalarea", tokenverify, async (req, res) => {

    try {
        jwt.verify(req.token, process.env.ACCESS_TOKEN, async (err, authdata) => {
            if (err) {
                res.json({ message: "invalid token" })
            } else {
                const _id = authdata._id;

                var candidate_function = await RecruiterFunctionarea.find({ userid: _id }).sort('-createdAt').limit(5).select("expertice_area").populate({ path: "expertice_area", select: "functionalname" })
                res.status(200).send(candidate_function)
            }
        })
    } catch (error) {
        res.status(400).send(error);
    }



})


app.get("/candidatelist", tokenverify, async (req, res) => {
    try {
        jwt.verify(req.token, process.env.ACCESS_TOKEN, async (err, authdata) => {
            if (err) {
                res.json({ message: "invalid token" })
            } else {
                const _id = authdata._id;
                var jobdata = await JobPost.find({ userid: _id }).select(["expertice_area", "company"]).populate({path: "company", select: "c_location"})
                let functionarea = [];
                    let cityname = [];
                    let functionalregex;
                    let cityregex;
                    for (let index = 0; index < jobdata.length; index++) {
                        functionarea.push(jobdata[index].expertice_area);
                        cityname.push(jobdata[index].company.c_location.formet_address);
                       

                        
                    }
                    functionalregex = functionarea.join("|");
                    cityregex = cityname.join("|");
                   
                
                var data = await Profiledata.find().populate("careerPreference");
                res.status(200).send(jobdata)
            }
        })
    } catch (error) {
        res.status(400).send(error);
    }

})







module.exports = app;